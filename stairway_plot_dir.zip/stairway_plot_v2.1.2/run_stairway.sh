#!/bin/bash
#SBATCH -c 1
#SBATCH --mem=24G
#SBATCH -t 24:00:00
#SBATCH --account=def-vlf
#SBATCH --mail-type=ALL
#SBATCH --mail-user=your_email@queensu.ca
#SBATCH --job-name=run_seabird_stairway
#SBATCH -o %x-%j.o
#SBATCH -e %x-%j.e

module load java/21.0.1

bash seabird_stairway_fold.blueprint.sh
